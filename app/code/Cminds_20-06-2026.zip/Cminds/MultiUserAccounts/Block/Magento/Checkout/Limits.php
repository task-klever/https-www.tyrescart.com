<?php
/**
 * Cminds MultiUserAccounts limits block.
 *
 * @category Cminds
 * @package  Cminds_MultiUserAccounts
 * @author   Cminds Team <info@cminds.com>
 */

namespace Cminds\MultiUserAccounts\Block\Magento\Checkout;

use Cminds\MultiUserAccounts\Api\SubaccountTransportRepositoryInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Customer\Model\Session as CustomerSession;
use Cminds\MultiUserAccounts\Helper\View as ViewHelper;
use Magento\Framework\View\Element\Template\Context;
use Magento\Customer\Helper\Session\CurrentCustomer;
use Magento\Newsletter\Model\SubscriberFactory;
use Magento\Customer\Helper\View;
use Magento\Framework\Pricing\PriceCurrencyInterface;

class Limits extends \Magento\Framework\View\Element\Template
{
    /**
     * View helper object.
     *
     * @var ViewHelper
     */
    private $viewHelper;
     /**
      * Session object.
      *
      * @var CustomerSession
      */
    private $customerSession;

    /**
     * Cached subscription object
     *
     * @var \Magento\Newsletter\Model\Subscriber
     */
    protected $_subscription;

    /**
     * @var \Magento\Newsletter\Model\SubscriberFactory
     */
    protected $_subscriberFactory;

    /**
     * @var \Magento\Customer\Helper\View
     */
    protected $_helperView;

    /**
     * @var \Magento\Customer\Helper\Session\CurrentCustomer
     */
    protected $currentCustomer;
    /**
     * @var SubaccountTransportRepositoryInterface
     */
    private $subaccountTransportRepository;
    /**
     * @var PriceCurrencyInterface
     */
    private $priceCurrency;

    /**
     * Constructor
     *
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Customer\Helper\Session\CurrentCustomer $currentCustomer
     * @param \Magento\Newsletter\Model\SubscriberFactory $subscriberFactory
     * @param \Magento\Customer\Helper\View $helperView
     * @param ViewHelper $viewHelper View helper object.
     * @param CustomerSession $customerSession
     * @param SubaccountTransportRepositoryInterface $subaccountTransportRepository
     * @param PriceCurrencyInterface $priceCurrency
     * @param array $data
     */
    public function __construct(
        Context $context,
        CurrentCustomer $currentCustomer,
        SubscriberFactory $subscriberFactory,
        View $helperView,
        ViewHelper $viewHelper,
        CustomerSession $customerSession,
        SubaccountTransportRepositoryInterface $subaccountTransportRepository,
        PriceCurrencyInterface $priceCurrency,
        array $data = []
    ) {
        $this->currentCustomer = $currentCustomer;
        $this->_subscriberFactory = $subscriberFactory;
        $this->customerSession = $customerSession;
        $this->_helperView = $helperView;
        $this->viewHelper = $viewHelper;
        parent::__construct($context, $data);
        $this->subaccountTransportRepository = $subaccountTransportRepository;
        $this->priceCurrency = $priceCurrency;
    }

    /**
     * Get month budget
     *
     * @return string full name
     */
    public function getSubaccountMonthBudget()
    {
        if (!$this->viewHelper->isShowMonthLimits()) {
            return false;
        }

        $subaccountData = $this->customerSession->getSubaccountData();

        if (!$subaccountData) {
            return false;
        }

        $subaccount = $this->subaccountTransportRepository->getByCustomerId($subaccountData->getCustomerId());

        if (!$subaccount->getId()) {
            return false;
        }

        return (float) $subaccount->getAdditionalInformationValue($subaccount::LIMIT_ORDER_MONTH);
    }

    public function formatPrice(float $price)
    {
        return $this->priceCurrency->format($price);
    }

    public function getRemainingAmount()
    {
        $customerOrders = $this->viewHelper->getOrdersFromCustomer();
        $ordersThisMonth = $customerOrders->addAttributeToFilter('created_at',
            ['from' => date('Y-m-01 00:00:00')]
        );

        return $this->getSubaccountMonthBudget() - $this->viewHelper->getOrdersGrandTotalSum($ordersThisMonth);
    }
}
