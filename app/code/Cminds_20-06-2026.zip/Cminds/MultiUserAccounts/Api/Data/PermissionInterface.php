<?php

namespace Cminds\MultiUserAccounts\Api\Data;

interface PermissionInterface
{

}
