/**
 * @category Cminds
 * @package  Cminds_MultiUserAccounts
 * @author   Cminds Team <info@cminds.com>
 */
var config = {
    map: {
        '*': {
            'Magento_Checkout/js/model/new-customer-address':'Cminds_MultiUserAccounts/js/model/new-customer-address',
            'Magento_Checkout/template/shipping-address/address-renderer/default.html':
                'Cminds_MultiUserAccounts/template/shipping-address/address-renderer/default.html',
            'Magento_Checkout/template/shipping-address/form.html':
                'Cminds_MultiUserAccounts/template/shipping-address/form.html',
            'Magento_Checkout/template/shipping-information/address-renderer/default.html':
                'Cminds_MultiUserAccounts/template/shipping-information/address-renderer/default.html',
            'Magento_Checkout/template/billing-address/details.html':
                'Cminds_MultiUserAccounts/template/billing-address/details.html',
            'Magento_Checkout/template/billing-address.html':
                'Cminds_MultiUserAccounts/template/billing-address.html'
        }
    },
    config: {
        mixins: {
            'Magento_Checkout/js/view/billing-address/list': {
                'Cminds_MultiUserAccounts/js/view/billing-address/list-mixin': true
            },
            'Magento_Checkout/js/view/shipping': {
                'Cminds_MultiUserAccounts/js/view/shipping-mixin': true
            },
            'Magento_Checkout/js/view/billing-address': {
                'Cminds_MultiUserAccounts/js/view/billing-address-mixin': true
            }
        }
    }
};
