/**
 * @category Cminds
 * @package  Cminds_MultiUserAccounts
 * @author   Cminds Team <info@cminds.com>
 */
define([
    'jquery',
    'uiComponent',
    'Magento_Customer/js/model/address-list',
    'mage/translate',
    'Magento_Customer/js/model/customer'
], function ($, Component, addressList, $t, customer) {
    'use strict';

    return function (Component) {

        // get MultiUserAccounts all settings of Force Use Of Parent Account Details For New Orders
        let isNewAddressAllow = $('.is_new_address_allow');

        return Component.extend({
            /**
             * @returns {Object} Chainable.
             */
            initConfig: function () {
                this._super();

                if (isNewAddressAllow && isNewAddressAllow.attr('multiple-addresses') == true && isNewAddressAllow.attr('new-address') == true) {
                    // remove 'New Address' option from Array
                    this.addressOptions.pop();
                }

                return this;
            },
        });
    }
});