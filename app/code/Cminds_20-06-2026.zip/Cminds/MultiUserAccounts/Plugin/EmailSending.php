<?php

namespace Cminds\MultiUserAccounts\Plugin;

use Closure;
use Cminds\MultiUserAccounts\Model\Config as ModuleConfig;
use Magento\Framework\Event\Observer;
use Magento\Quote\Observer\SubmitObserver;

class EmailSending
{
    protected $moduleConfig;

    public function __construct(
        ModuleConfig $moduleConfig
    ) {
        $this->moduleConfig = $moduleConfig;
    }

    public function aroundExecute(
        SubmitObserver $subject,
        Closure $proceed,
        Observer $observer
    ) {
        if ($this->moduleConfig->isEnabled() === false) {
            $proceed($observer);
        }
    }
}
