<?php
/**
 * Cminds MultiUserAccounts quote address validator.
 *
 * @category Cminds
 * @package  Cminds_MultiUserAccounts
 * @author   Cminds Team <info@cminds.com>
 */
declare(strict_types=1);

namespace Cminds\MultiUserAccounts\Model\Plugin\Quote;

use Cminds\MultiUserAccounts\Helper\View as ViewHelper;
use Cminds\MultiUserAccounts\Model\Config as ModuleConfig;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Api\Data\AddressInterface;
use Magento\Quote\Api\Data\CartInterface;
use Cminds\MultiUserAccounts\Api\SubaccountRepositoryInterface;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\Registry;

/**
 * Class QuoteAddressValidatorAround
 *
 * @package Cminds\MultiUserAccounts\Model\Plugin\Quote
 */
class QuoteAddressValidatorAround
{
    /**
     * @var ModuleConfig
     */
    private $moduleConfig;

    /**
     * @var ViewHelper
     */
    private $viewHelper;

    /**
     * Address factory.
     *
     * @var \Magento\Customer\Api\AddressRepositoryInterface
     */
    protected $addressRepository;

    /**
     * Customer repository.
     *
     * @var \Magento\Customer\Api\CustomerRepositoryInterface
     */
    protected $customerRepository;

    /**
     * @var SubaccountRepositoryInterface
     */
    protected $subaccountRepository;

    /**
     * @var CustomerSession
     */
    protected $session;

    /**
     * @var Registry
     */
    private $coreRegistry;

    /**
     * QuoteAddressValidatorAround constructor.
     *
     * @param ModuleConfig $moduleConfig
     * @param ViewHelper $viewHelper
     * @param \Magento\Customer\Api\AddressRepositoryInterface $addressRepository
     * @param \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository
     * @param SubaccountRepositoryInterface $subaccountRepository
     * @param CustomerSession $session
     */
    public function __construct(
        ModuleConfig $moduleConfig,
        ViewHelper $viewHelper,
        \Magento\Customer\Api\AddressRepositoryInterface $addressRepository,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
        SubaccountRepositoryInterface $subaccountRepository,
        CustomerSession $session,
        Registry $coreRegistry
    ) {
        $this->moduleConfig = $moduleConfig;
        $this->viewHelper = $viewHelper;
        $this->addressRepository = $addressRepository;
        $this->customerRepository = $customerRepository;
        $this->subaccountRepository = $subaccountRepository;
        $this->session = $session;
        $this->coreRegistry = $coreRegistry;
    }

    /**
     * @param \Magento\Quote\Model\QuoteAddressValidator $subject
     * @param callable $proceed
     * @param CartInterface $cart
     * @param AddressInterface $address
     * @throws NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function aroundValidateForCart(\Magento\Quote\Model\QuoteAddressValidator $subject, callable $proceed, CartInterface $cart, AddressInterface $address)
    {
        if ($this->moduleConfig->isEnabled() === false
            || $this->viewHelper->isSubaccountLoggedIn() === false
        ) {
            $proceed($cart, $address);
        } else {
            if ($this->coreRegistry->registry(\Cminds\MultiUserAccounts\Model\Plugin\Customer\Address\Collection\Load\Plugin::PLUGIN_SKIP)) {
                $proceed($cart, $address);
            }
           $this->doValidate($address, $cart->getCustomerIsGuest() ? null : $cart->getCustomer()->getId());
        }
    }

    /**
     * @param AddressInterface $address
     * @param int|null $customerId
     * @throws NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    private function doValidate(AddressInterface $address, $customerId): void
    {
        $parentId = null;
        $subaccountDataObject = $this->session->getSubaccountData();
        if (!empty($subaccountDataObject) && $subaccountDataObject->getCustomerId()) {
            $customerId = $subaccountDataObject->getCustomerId();
            if (!empty($subaccountDataObject->getParentCustomerId())) {
                $parentId = $subaccountDataObject->getParentCustomerId();
            }
        }

        //validate customer id
        if ($customerId) {
            $customer = $this->customerRepository->getById($customerId);
            if (!$customer->getId()) {
                $this->viewHelper->printLog('Invalid customer id ' . $customerId);
                throw new \Magento\Framework\Exception\NoSuchEntityException(
                    __('Invalid customer id %1', $customerId)
                );
            }
        }

        if ($address->getCustomerAddressId()) {
            //Existing address cannot belong to a guest
            if (!$customerId) {
                $this->viewHelper->printLog('Invalid customer address id ' . $address->getCustomerAddressId());
                throw new \Magento\Framework\Exception\NoSuchEntityException(
                    __('Invalid customer address id %1', $address->getCustomerAddressId())
                );
            }
            //Validating address ID
            try {
                $this->addressRepository->getById($address->getCustomerAddressId());
            } catch (NoSuchEntityException $e) {
                $this->viewHelper->printLog('Invalid address id ' . $address->getId());
                throw new \Magento\Framework\Exception\NoSuchEntityException(
                    __('Invalid address id %1', $address->getId())
                );
            }
            //Finding available customer's addresses
            $applicableAddressIds = array_map(function ($address) {
                /** @var \Magento\Customer\Api\Data\AddressInterface $address */
                return $address->getId();
            }, $this->customerRepository->getById($customerId)->getAddresses());

            if (!empty($parentId)) {
                //Finding available customer's parent addresses
                $parentApplicableAddressIds = array_map(function ($address) {
                    /** @var \Magento\Customer\Api\Data\AddressInterface $address */
                    return $address->getId();
                }, $this->customerRepository->getById($parentId)->getAddresses());

                $applicableAddressIds = array_unique(
                    array_merge($applicableAddressIds, $parentApplicableAddressIds)
                );
            }

            // If address is customer's or parent's - pass validation
            if (count($applicableAddressIds) > 0 && !in_array($address->getCustomerAddressId(), $applicableAddressIds)) {
                $this->viewHelper->printLog('Invalid parent or customer address id ' . $address->getCustomerAddressId());
                throw new \Magento\Framework\Exception\NoSuchEntityException(
                    __('Invalid parent or customer address id %1', $address->getCustomerAddressId())
                );
            }
        }
    }
}
