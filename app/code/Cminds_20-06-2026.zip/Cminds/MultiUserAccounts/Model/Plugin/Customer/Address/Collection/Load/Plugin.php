<?php
/**
 * @category Cminds
 * @package  Cminds_MultiUserAccounts
 * @author   Cminds Team <info@cminds.com>
 */
declare(strict_types=1);

namespace Cminds\MultiUserAccounts\Model\Plugin\Customer\Address\Collection\Load;

use Cminds\MultiUserAccounts\Api\Data\SubaccountTransportInterface;
use Cminds\MultiUserAccounts\Helper\View as ViewHelper;
use Cminds\MultiUserAccounts\Model\Config as ModuleConfig;
use Magento\Customer\Model\Address;
use Magento\Customer\Model\Customer;
use Magento\Customer\Model\CustomerFactory;
use Magento\Customer\Model\ResourceModel\Address\Collection;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\App\Request\Http as Request;
use Magento\Framework\Registry;

/**
 * Cminds MultiUserAccounts customer address collection plugin.
 */
class Plugin
{
    const PLUGIN_SKIP = 'cminds_multiuseraccounts_customer_address_collection_plugin_skip';

    const SKIP_SAVE_ADDRESS_ACTION = 'subaccounts-subaccounts-manage-editPost';

    /**
     * @var CustomerSession
     */
    private $customerSession;

    /**
     * @var ModuleConfig
     */
    private $moduleConfig;

    /**
     * @var ViewHelper
     */
    private $viewHelper;

    /**
     * @var CustomerFactory
     */
    private $customerFactory;

    /**
     * @var Registry
     */
    private $coreRegistry;

    /**
     * @var Request
     */
    private $request;

    /**
     * Object constructor.
     *
     * @param CustomerSession $customerSession
     * @param ModuleConfig    $moduleConfig
     * @param ViewHelper      $viewHelper
     * @param CustomerFactory $customerFactory
     * @param Registry $coreRegistry
     */
    public function __construct(
        CustomerSession $customerSession,
        ModuleConfig $moduleConfig,
        ViewHelper $viewHelper,
        CustomerFactory $customerFactory,
        Registry $coreRegistry,
        Request $request
    ) {
        $this->customerSession = $customerSession;
        $this->moduleConfig = $moduleConfig;
        $this->viewHelper = $viewHelper;
        $this->customerFactory = $customerFactory;
        $this->coreRegistry = $coreRegistry;
        $this->request = $request;

    }

    /**
     * Customer collection after load plugin.
     *
     * @param Collection $subject
     * @param Collection $result
     *
     * @return $this|Collection
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function afterLoad(Collection $subject, Collection $result)
    {
        if ($this->coreRegistry->registry(self::PLUGIN_SKIP)) {
            return $result;
        }

        $this->coreRegistry->register(self::PLUGIN_SKIP, true);

        if ($this->moduleConfig->isEnabled() === false
            || $this->viewHelper->isSubaccountLoggedIn() === false
        ) {
            $this->coreRegistry->unregister(self::PLUGIN_SKIP);

            return $result;
        }

        /** @var SubaccountTransportInterface $subaccountTransportDataObject */
        $subaccountTransportDataObject = $this->customerSession->getSubaccountData();

        $forceCompanyName = (bool)($subaccountTransportDataObject->getForceUsageParentCompanyNamePermission()
            || $this->moduleConfig->isForceUseParentAccountDetailsForOrderEnabled()
        );
        $forceVat = (bool)($subaccountTransportDataObject->getForceUsageParentVatPermission()
            || $this->moduleConfig->isForceUseParentAccountDetailsForOrderEnabled()
        );
        $forceAddress = (bool)($subaccountTransportDataObject->getForceUsageParentAddressesPermission()
            || $this->moduleConfig->isForceUseParentAccountDetailsForOrderEnabled()
        );

        $canManageAddresses = (bool)($subaccountTransportDataObject
            ->getAccountAddressBookModificationPermission());

        if ($forceCompanyName === false
            && $forceVat === false
            && $forceAddress === false
            && $canManageAddresses === true
        ) {
            $this->coreRegistry->unregister(self::PLUGIN_SKIP);

            return $result;
        }

        // If forced address is enable
        if ($forceAddress === true) {
            if ($this->request->getRouteName()
                . '-' . $this->request->getModuleName()
                . '-' . $this->request->getControllerName()
                . '-' . $this->request->getActionName() == self::SKIP_SAVE_ADDRESS_ACTION) {
                return $result;
            }

            /** @var Customer $parentCustomer */
            $parentCustomer = $this->customerFactory->create()
                ->load($subaccountTransportDataObject->getParentCustomerId());

            /** @var Address $parentBillingAddress */
            $parentBillingAddress = $parentCustomer->getDefaultBillingAddress();
            $parentShippingAddress = $parentCustomer->getDefaultShippingAddress();

            if ($parentBillingAddress !== false) {
                $result->removeAllItems();
                if ($this->moduleConfig->isAllowMultipleParentAddressesEnabled()) {
                    // add all parent addresses
                    foreach ($parentCustomer->getAddresses() as $address) {
                        $result->addItem($address);
                    }
                } else {
                    // add the parent default address item
                    $result->addItem($parentBillingAddress);
                    if ($parentShippingAddress !== false && $parentBillingAddress->getId() != $parentShippingAddress->getId()) {
                        $shippingAddressId = $parentShippingAddress->getId();
                        $canAdd = true;
                        foreach ($result as $cycleAddress) {
                            if ($cycleAddress->getId() == $shippingAddressId) {
                                $canAdd = false;
                            }
                        }
                        if ($canAdd) {
                            $result->addItem($parentShippingAddress);
                        }
                    }
                }

                // Set in all available addresses forced data if option enabled.
                if ($result->getItems()) {
                    foreach ($result->getItems() as $address) {
                        if ($forceCompanyName) {
                            $address->setCompany($parentBillingAddress->getCompany());
                        }
                        if ($forceVat) {
                            $address->setVatId($parentBillingAddress->getVatId());
                        }
                    }
                }
            }

            foreach ($result->getItems() as $item) {
                $item->setRealCustomerId($parentCustomer->getId());
            }

            $this->coreRegistry->unregister(self::PLUGIN_SKIP);

            return $result;
        }

        if ($canManageAddresses === false) {
            $storeId = $this->viewHelper->getStoreId();
            $addresses = $this->customerSession->getCustomer()->getAddresses();
            $customer = $this->customerSession->getCustomer();

            // Search the address assigned to this store
            $isAssigned = false;
            foreach ($addresses as $address) {
                if ($address->getStoreView() != null && $address->getStoreView() === $storeId) {
                    $result->removeAllItems();
                    //add the store view address item
                    $result->addItem($address);
                    $isAssigned = true;
                }
            }
            if ($isAssigned == false) {
                $defaultBillingAddress = $customer->getDefaultBillingAddress();
                $defaultShippingAddress = $customer->getDefaultShippingAddress();
                if ($defaultBillingAddress == false && $defaultShippingAddress == false) {
                    $this->coreRegistry->unregister(self::PLUGIN_SKIP);
                    return $result;
                }

                $result->removeAllItems();
                //assign the customer default addresses
                if ($defaultBillingAddress) {
                    $result->addItem($defaultBillingAddress);
                }
                if ($defaultShippingAddress
                    && $defaultBillingAddress->getId() != $defaultShippingAddress->getId()
                ) {
                    $result->addItem($defaultShippingAddress);
                }
            }
        }

        $this->coreRegistry->unregister(self::PLUGIN_SKIP);

        return $result;
    }
}
