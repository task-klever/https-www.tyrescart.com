<?php
/**
 * @category Cminds
 * @package  Cminds_MultiUserAccounts
 * @author   Cminds Team <info@cminds.com>
 */
declare(strict_types=1);

namespace Cminds\MultiUserAccounts\Model\Service\Order;

use Cminds\MultiUserAccounts\Api\SubaccountTransportRepositoryInterface;
use Cminds\MultiUserAccounts\Api\Data\SubaccountTransportInterface;
use Cminds\MultiUserAccounts\Helper\View as ViewHelper;
use Cminds\MultiUserAccounts\Model\Config as ModuleConfig;
use Cminds\MultiUserAccounts\Model\ResourceModel\Subaccount\CollectionFactory as SubaccountCollectionFactory;
use Cminds\MultiUserAccounts\Api\Data\SubaccountInterface;
use Cminds\MultiUserAccounts\Helper\Email as EmailHelper;
use Magento\Quote\Model\Quote;
use Magento\Customer\Model\CustomerFactory;
use Magento\Customer\Model\CustomerRegistry;
use Magento\Framework\DataObjectFactory;
use Magento\Framework\UrlInterface;
use Magento\Customer\Model\Session;

/**
 * Cminds MultiUserAccounts Approve Request Model.
 *
 * @package Cminds\MultiUserAccounts\Model\Service\Order
 */
class ApproveRequest
{
    const IS_SUBACCOUNT_HAS_NO_MASTER = 0;
    const IS_SUBACCOUNT_HAS_MASTER_FIRST_LEVEL = 1;
    const IS_SUBACCOUNT_HAS_MASTER_SECOND_LEVEL = 2;

    /**
     * @var SubaccountTransportRepositoryInterface
     */
    private $subaccountTransportRepository;

    /**
     * @var CustomerRegistry
     */
    private $customerRegistry;

    /**
     * @var ModuleConfig
     */
    private $moduleConfig;

    /**
     * @var ViewHelper
     */
    private $viewHelper;

    /**
     * @var EmailHelper
     */
    private $emailHelper;

    /**
     * @var CustomerFactory
     */
    private $customerFactory;

    /**
     * @var SubaccountCollectionFactory
     */
    private $subaccountCollectionFactory;

    /**
     * @var DataObjectFactory
     */
    private $dataObjectFactory;

    /**
     * @var UrlInterface
     */
    private $urlBuilder;

    /**
     * @var Session
     */
    private $customerSession;

    /**
     * ApproveRequest constructor.
     *
     * @param SubaccountTransportRepositoryInterface $subaccountTransportRepository
     * @param CustomerRegistry $customerRegistry
     * @param ModuleConfig $moduleConfig
     * @param ViewHelper $viewHelper
     * @param EmailHelper $emailHelper
     * @param SubaccountCollectionFactory $subaccountCollectionFactory
     * @param CustomerFactory $customerFactory
     * @param DataObjectFactory $dataObjectFactory
     * @param UrlInterface $urlBuilder
     * @param Session $customerSession
     */
    public function __construct(
        SubaccountTransportRepositoryInterface $subaccountTransportRepository,
        CustomerRegistry $customerRegistry,
        ModuleConfig $moduleConfig,
        ViewHelper $viewHelper,
        EmailHelper $emailHelper,
        SubaccountCollectionFactory $subaccountCollectionFactory,
        CustomerFactory $customerFactory,
        DataObjectFactory $dataObjectFactory,
        UrlInterface $urlBuilder,
        Session $customerSession
    ) {
        $this->subaccountTransportRepository = $subaccountTransportRepository;
        $this->customerRegistry = $customerRegistry;
        $this->moduleConfig = $moduleConfig;
        $this->viewHelper = $viewHelper;
        $this->emailHelper = $emailHelper;
        $this->subaccountCollectionFactory = $subaccountCollectionFactory;
        $this->customerFactory = $customerFactory;
        $this->dataObjectFactory = $dataObjectFactory;
        $this->urlBuilder = $urlBuilder;
        $this->customerSession = $customerSession;
    }

    /**
     * @param Quote $quoteModel
     * @param       $subaccount
     *
     * @return bool
     */
    public function canAuthorize(Quote $quoteModel, $subaccount)
    {
        $authorizers = $this->getAuthorizers($quoteModel);
        $quoteGrandTotal = (float)$quoteModel->getBaseGrandTotal();

        foreach ($authorizers as $authorizerSubaccount) {
            if ($authorizerSubaccount->getId() === $subaccount->getId()) {
                // Checking allowed approval amount
                $allowedAmount = (float)$authorizerSubaccount->getAdditionalInformationValue(
                    'manage_order_approval_permission_amount'
                );
                if ($allowedAmount > 0 && $allowedAmount < $quoteGrandTotal) {
                    return 'Your order amount limit for authorization does not allow to authorize this order!';
                }

                return '';
            }
        }

        return 'You are not allowed to authorize this order.';
    }

    /**
     * @param Quote $quoteModel
     * @return $this
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function processNotification(Quote $quoteModel)
    {
        $subaccountId = $quoteModel->getSubaccountId();

        /** @var SubaccountTransportInterface $reqSubaccountTransportDataObject */
        $subaccountTransportDataObject = $this->subaccountTransportRepository->getByCustomerId($subaccountId);
        $parentCustomerId = $subaccountTransportDataObject->getParentCustomerId();
        $reqSubaccountName = $this->viewHelper->getSubaccountName($subaccountTransportDataObject);

        /** @var \Magento\Customer\Model\Customer $parentCustomerModel */
        $parentCustomerModel = $this->customerRegistry->retrieve($parentCustomerId);

        $authorizers = $this->getAuthorizers($quoteModel);

        /* does it need authorization for the order before approval? */
        if ($this->moduleConfig->isOrderApprovalRequestAuthorizationRequired() == true) {
            // Looking for authorizers
            $isAuthorized = (int)$quoteModel->getIsAuthorized();
            if ($isAuthorized == 0) {                   // if quote is not authorized yet
                if (count($authorizers) == 0) {         // if authorizers are absent
                    $isAuthorized = 1;                  // not need to authorize
                } else {
                    ksort($authorizers);
                }
            }
        } else {
            $isAuthorized = 1;                    // does not need in authorization
        }

        $hash = sha1(time() . rand());
        $quoteModel
            ->setApproveHash($hash)
            ->setIsAuthorized($isAuthorized)
            ->save();

        /**
         * Send authorize request notification to authorizers.
         */
        if ($isAuthorized == 0) {
            foreach ($authorizers as $authorizer) {
                $subaccountName = $this->viewHelper->getSubaccountName($authorizer);
                $this->sendOrderApprovalRequest(
                    $subaccountName,
                    $authorizer->getEmail(),
                    $reqSubaccountName,
                    $quoteModel,
                    $hash,
                    $isAuthorized
                );
            }

            return $this;
        }

        /**
         * Send approval request notification to approvers.
         */
        $approvers = $this->getApprovers($quoteModel);
        ksort($approvers);

        /**
         * Send approval request to parent account.
         */
        $sendParentNotification = $this->moduleConfig->shouldParentReceiveAllNotifications();

        if (count($approvers) == 0) {
            $sendParentNotification = true;
        }

        if (count($authorizers) == 0 && count($approvers) == 0) {
            // look for approver on the up level (master)
            $master = $this->getMasterApprover($parentCustomerId);

            if (!$master) {
                $sendParentNotification = false;     // didn't find approver master
            } else {
                $parentCustomerModel = $master;
            }
        }

        if ($sendParentNotification && $isAuthorized == 1) {
            $this->sendOrderApprovalRequest(
                $parentCustomerModel->getName(),
                $parentCustomerModel->getEmail(),
                $reqSubaccountName,
                $quoteModel,
                $hash
            );
        }
    }

    /**
     * @param $parentCustomerId
     * @return bool|\Magento\Customer\Model\Customer
     */
    public function getMasterApprover($parentCustomerId)
    {
        $collection = $this->subaccountCollectionFactory->create();
        $collection
            ->addFieldToFilter('customer_id', $parentCustomerId)
            ->getFirstItem();
        if ($collection->getSize() == 0) {
            // master account
            $customerMaster = $this->customerFactory->create()->load($parentCustomerId);
        } else {
            foreach ($collection as $item) {
                // parent account with permission
                $master = $this->subaccountTransportRepository->getByCustomerId($item->getCustomerId());
                // is parent account has approval permission
                if ($master->getManageOrderApprovalPermission()) {
                    $customerMaster = $this->customerFactory->create()->load($parentCustomerId);
                } else {
                    return false;
                }
            }
        }

        return $customerMaster;
    }

    /**
     * @param Quote $quoteModel
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function processAuthorization(Quote $quoteModel)
    {
        $currentSubaccount = $this->customerSession->getSubaccountData();

        $parentCustomerId = $currentSubaccount->getParentCustomerId();
        $SubaccountName = $currentSubaccount->getFirstname() . ' ' . $currentSubaccount->getLastname();

        /** @var \Magento\Customer\Model\Customer $parentCustomerModel */
        $parentCustomerModel = $this->customerRegistry->retrieve($parentCustomerId);

        $isAuthorized = 1;
        $hash = sha1(time() . rand());
        $quoteModel
            ->setApproveHash($hash)
            ->setIsAuthorized($isAuthorized)
            ->save();

        /**
         * Send approval request notification to approvers.
         */
        $approvers = $this->getApprovers($quoteModel);
        ksort($approvers);

        /**
         * Send approval request to parent account.
         */
        $sendParentNotification = $this->moduleConfig->shouldParentReceiveAllNotifications();

        if (count($approvers) == 0) {
            $sendParentNotification = true;
        }

        if ($sendParentNotification && $isAuthorized == 1) {
            $this->sendOrderApprovalRequest(
                $parentCustomerModel->getName(),
                $parentCustomerModel->getEmail(),
                $SubaccountName,
                $quoteModel,
                $hash
            );
        }

        return '';
    }

    /**
     * @param Quote $quoteModel
     *
     * @return int
     */
    private function getParentAccountId($subaccountId)
    {
        /** @var SubaccountTransportInterface $reqSubaccountTransportDataObject */
        $reqSubaccountTransportDataObject = $this->subaccountTransportRepository
            ->getByCustomerId($subaccountId);

        $parentCustomerId = $reqSubaccountTransportDataObject
            ->getParentCustomerId();

        return $parentCustomerId;
    }

    /**
     * @param string $approverName
     * @param string $approverEmail
     * @param string $requesterName
     * @param int    $quoteId
     * @param string $hash
     * @param int    $isApproval
     *
     * @return ApproveRequest
     */
    private function sendOrderApprovalRequest(
        $approverName,
        $approverEmail,
        $requesterName,
        $quote,
        $hash,
        $isApproval = 1
    ) {
        $url = 'subaccounts/order/approve';
        if ($isApproval === 0) {
            $url = 'subaccounts/order/authorize';
        }
        $customerAccountUrl = 'customer/account';

        $emailVariablesObject = $this->dataObjectFactory->create();
        $emailVariablesObject->setData([
            'approver_name' => $approverName,
            'requester_name' => $requesterName,
            'customer_account_url' => $this->urlBuilder->getUrl($customerAccountUrl),
            'approve_url' => $this->urlBuilder->getUrl(
                $url,
                ['id' => $quote->getId(), 'hash' => $hash]
            ),
        ]);

        if ($isApproval == 1) {
            $this->emailHelper->sendCheckoutOrderApproveRequestEmail(
                [
                    'name' => $approverName,
                    'email' => $approverEmail,
                ],
                ['data' => $emailVariablesObject]
            );
        } else {
            $this->emailHelper->sendCheckoutOrderAuthorizationRequestEmail(
                [
                    'name' => $approverName,
                    'email' => $approverEmail,
                ],
                ['data' => $emailVariablesObject]
            );
        }

        return $this;
    }

    /**
     * @param Quote $quoteModel
     * @return array
     */
    public function getApprovers(Quote $quoteModel)
    {
        $customerId = $quoteModel->getCustomerId();
        $parentCustomerId = $this->getParentAccountId($customerId);
        $approvers = [];

        /* Checking parent on approving permission */
        $parentCollection = $this->subaccountCollectionFactory->create();
        $parentCollection->addFieldToFilter('customer_id', $parentCustomerId)->getFirstItem();
        if ($parentCollection->getSize() > 0) {
            foreach ($parentCollection as $item) {
                $parentId = $item->getParentCustomerId();
                $parents = $this->subaccountCollectionFactory->create();
                $parents->addFieldToFilter('customer_id', $parentId)->getFirstItem();
                if ($parents->getSize() > 0) {
                    $parentTransportData = $this->subaccountTransportRepository->getByCustomerId($parentId);
                    // Checking permission
                    if ($parentTransportData->getManageOrderApprovalPermission()) {
                        $approvers[$parentTransportData->getId()] = $parentTransportData;
                    }
                }
            }
        }

        return $approvers;
    }

    /**
     * @param Quote $quoteModel
     * @return array
     */
    public function getAuthorizers(Quote $quoteModel)
    {
        $customerId = $quoteModel->getCustomerId();
        $parentCustomerId = $this->getParentAccountId($customerId);
        $authorizers = [];

        /* Checking parent on authorization permission */
        $parentCollection = $this->subaccountCollectionFactory->create()
            ->addFieldToFilter('customer_id', $parentCustomerId);

        if (count($parentCollection) > 0) {
            $parentTransportData = $this->subaccountTransportRepository->getByCustomerId($parentCustomerId);
            // Checking permission
            if ($parentTransportData->getManageOrderAuthorizePermission()) {
                $authorizers[$parentTransportData->getId()] = $parentTransportData;
            }
        }

        return $authorizers;
    }

    /**
     * check Order Approval Permission Amount for authorizers and approvers
     *
     * @param Quote $subaccountQuote
     * @return bool
     */
    public function canOrderBeApproved(Quote $subaccountQuote)
    {
        $parentCustomerId = $this->getParentAccountId($subaccountQuote->getCustomerId());
        $master = $this->getLevelMasterAccount($parentCustomerId);

        if ($master == self::IS_SUBACCOUNT_HAS_MASTER_FIRST_LEVEL) {
            return '';
        }

        $quoteGrandTotal = (float)$subaccountQuote->getBaseGrandTotal();
        /* check Order Approval Permission Amount for sub-authorizers */
        if ($this->moduleConfig->isOrderApprovalRequestAuthorizationRequired() == true) {
            $iAllowed = false;
            $authorizers = $this->getAuthorizers($subaccountQuote);
            if (count($authorizers) > 0) {
                ksort($authorizers);
                foreach ($authorizers as $authorizer) {
                    // Checking allowed approval amount
                    $allowedAmount = (float)$authorizer->getAdditionalInformationValue(
                        'manage_order_approval_permission_amount'
                    );
                    if ($allowedAmount == 0 || $allowedAmount >= $quoteGrandTotal) {
                        $iAllowed = true;
                    }
                }
                if (!$iAllowed) {
                    return 'This order cannot be authorized, as your authorizers have an order amount limit for authorization!';
                }
            } else {
                return 'This order has to be authorized but you do not have any autorizers!';
            }
        }

        /* check Order Approval Permission Amount for sub-approvers */
        $iAllowed = false;
        $approvers = $this->getApprovers($subaccountQuote);
        if (count($approvers) > 0) {
            ksort($approvers);
            foreach ($approvers as $approver) {
                // Checking allowed approval amount
                $allowedAmount = (float)$approver->getAdditionalInformationValue(
                    'manage_order_approval_permission_amount'
                );
                if ($allowedAmount == 0 || $allowedAmount >= $quoteGrandTotal) {
                    $iAllowed = true;
                }
            }
            if (!$iAllowed) {
                return 'This order cannot be approved, as your approvers have an order amount limit for approving!';
            }
        } else {
            if ($master == self::IS_SUBACCOUNT_HAS_NO_MASTER) {
                return 'This order can not be approved, as your parent account does not have approving permission!';
            }
        }

        return '';
    }

    /**
     * @param $parentCustomerId
     * @return int
     */
    public function getLevelMasterAccount($parentCustomerId)
    {
        $collection = $this->subaccountCollectionFactory->create();
        $collection->addFieldToFilter('customer_id', $parentCustomerId)->getFirstItem();
        if ($collection->getSize() > 0) {
            foreach ($collection as $item) {
                $parentId = $item->getParentCustomerId();
                $parent = $this->subaccountCollectionFactory->create();
                $parent->addFieldToFilter('customer_id', $parentId)->getFirstItem();
                if ($parent->getSize() > 0) {
                    return self::IS_SUBACCOUNT_HAS_NO_MASTER;
                } else {
                    return self::IS_SUBACCOUNT_HAS_MASTER_SECOND_LEVEL;
                }
            }
        }

        return self::IS_SUBACCOUNT_HAS_MASTER_FIRST_LEVEL;
    }
}
