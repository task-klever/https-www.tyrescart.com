<?php
namespace Cminds\MultiUserAccounts\Model\Config\Source;

use Magento\Framework\Data\OptionSourceInterface;
use Magento\Payment\Model\Config;

/**
 * Cminds MultiUserAccounts PaymentMethod source config model.
 *
 * @category Cminds
 * @package  Cminds_MultiUserAccounts
 * @author   Cminds Team <info@cminds.com>
 */
class PaymentMethod implements OptionSourceInterface
{
    /**
     * @var Config
     */
    protected $paymentConfig;

    /**
     * @param Config $paymentConfig
     */
    public function __construct(
        Config $paymentConfig
    ) {
        $this->paymentConfig = $paymentConfig;
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $list = [];
        foreach ($this->paymentConfig->getActiveMethods() as $paymentMethod) {
            $list[] = [
                'value' => $paymentMethod->getCode(),
                'label' => $paymentMethod->getTitle()
            ];
        }
        return $list;
    }
}
