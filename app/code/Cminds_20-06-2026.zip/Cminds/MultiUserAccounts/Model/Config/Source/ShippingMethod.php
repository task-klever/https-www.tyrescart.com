<?php
namespace Cminds\MultiUserAccounts\Model\Config\Source;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Data\OptionSourceInterface;
use Magento\Shipping\Model\Config;

/**
 * Cminds MultiUserAccounts ShippingMethod source config model.
 *
 * @category Cminds
 * @package  Cminds_MultiUserAccounts
 * @author   Cminds Team <info@cminds.com>
 */
class ShippingMethod implements OptionSourceInterface
{
    /**
     * @var \Magento\Payment\Model\Config
     */
    protected $shippingConfig;

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @param Config $shippingConfig
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        Config $shippingConfig,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->shippingConfig = $shippingConfig;
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $list = [];
        foreach ($this->shippingConfig->getActiveCarriers() as $carrierCode => $carrierModel) {
            if ($carrierMethods = $carrierModel->getAllowedMethods()) {
                foreach ($carrierMethods as $methodCode => $method) {
                    $code = $carrierCode . '_' . $methodCode;
                    $list[] = [
                        'value' => $code,
                        'label' => $method
                    ];
                }
            }
        }
        return $list;
    }
}
